function [fmax] = Fmax(g, m, mu, percm)

fmax = g * m * percm * mu;

end