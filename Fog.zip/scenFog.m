%% General sim preparations for Foggy Conditions
% Memory and workspace
clear all variables; clc;

dofig  = false;
dosavedata = true;
dosavefig  = true;

% Time Horizon (15min)
Sim.dt       = 0.1;             % sec
Sim.Tsim     = 15*60;           % sec
Sim.timeline = 0:Sim.dt:Sim.Tsim-Sim.dt;    % sec
Sim.numsteps = numel(Sim.timeline);

% update progress every ... steps
Sim.dtprogress = 450;

% road stretch
Sim.xstart =  0;
Sim.xmax   = 6e3;

% max nr of vehicles generated:
Sim.numvehicles = 350;

% Safe zone: we cannot apply reaction time logic close to origin.
Sim.safezone = 5*40; % 5 (sec) * 40 (m/s) ("Faint" drivers * very high speed)

%% Scenario preparations

% base OD profile (sinusoidal curve)
q = zeros(size(Sim.timeline));
sinebase  = 1+sin(1.5*pi/Sim.Tsim * Sim.timeline);

qbase = [900  * ones(1,0.1*Sim.numsteps), ...
    2200 * ones(1,0.3*Sim.numsteps), ...
    900  * ones(1,0.6*Sim.numsteps)];

Sim.q = qbase;

%% here's the list of scenario's
scenarios = {...
%    'scenBase_V=439m',...
%    'scenBase_RT_V=439m',...
%    'scenBase_RT_PES_V=439m',...
%    'scenBase_RT_PEV_V=439m',...
    'scenBase_V=93m',...
};

% run over all of them
numscen = numel(scenarios);

%  I must fix this!!!(rection time)
for itau = 0
    Sim.base_tau    = itau/10;
    tau_str = sprintf('tau=%.2d',itau);
    
%    fprintf('\n-------------------------\n');
%    fprintf('BASE REACTION TIME = %.1f  \n',Sim.base_tau);
%    fprintf('-------------------------\n');
    
    % over all the scenarios
    for iscenario = 1 : numscen
        
        % BASE Settings for the scenarios
        
       % A bottleneck at 4 and 4.5
        Sim.xDisturbance  = [4e3,4.5e3];     % disturbance location
        Sim.tDisturbance  = [1, 15] * 60;    % disturbance
        Sim.disturbanceStrength = 0.36;      % Severity (qcap = 2100 veh/h, u = 33.33 m/s)
    
        % Base scenario:
        Sim.doHF          = true;      % do we compute HF?
        Sim.doDistraction = false;   % do we simulate a distraction?
        Sim.doDisturbance = true;    % do we force an additional disturbances, lets assume a flow conserving bottleneck?
        Sim.doHeterogeneity = false; % do we vary with critical task saturation?
        %Sim.base_tau       = itau;     % do we give drivers a base reaction time?
        Sim.doHF_perc_s     = false;     % do we have HF affect perception of distance gaps
        Sim.doHF_perc_v     = false;     % do we have HF affect perception of speed differences
        Sim.doHF_tau        = false;     % do we have tau = tau_{senstation} + tau_{perception}
        Sim.doHF_v0         = false;     % do we have HF affect v0
        Sim.doHF_T          = false;     % do we have HF affect T
        Sim.doHF_TD         = false;     % do we have HF affect Task Difficulty
        
        % What is the perception biase of the driving population?
        Sim.doHF_prob_overestimation = 0.75;
        % Here is the same as the previous one but you work with fractions!
        % Sim.doHF_perc_s_over = 0.5;  % fraction of drivers that overestimates
        % distance gaps/speeds if set to 0, 100%
        % underestimates, if set to 1 100%
        % overestimates, and any number in between
        % yields a mix (default: 50-50)
        % selected vehicles for HF plots
        Sim.iHF = [60,200];
        
        % select scenario
        Sim.scenario = scenarios{iscenario};
        switch Sim.scenario
		
%% CLEAR CONDITIONS
		   case 'scenBase_V=439m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 439;      % m visibility distance associated with the time headways (assumed)
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
           case 'scenBase_RT_V=439m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 439;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
           case 'scenBase_RT_PES_V=439m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 439;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_s= true;     % do we have HF affect perception of distance gaps
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD); 
           case 'scenBase_RT_PEV_V=439m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 439;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_v= true;     % do we have HF affect perception of speed
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);  
           case 'scenBase_RT_PESV_V=439m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 439;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_s= true;     % do we have HF affect perception of distance gaps
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD); 
           case 'scenBase_RT_PESV_BAV_V=439m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 439;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_s= true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v= true;     % do we have HF affect perception of speed
                Sim.doHF_v0    = true;     % do we have HF affect v0
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);  
           case 'scenBase_RT_PESV_BAV_H_V=439m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 439;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_s= true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v= true;     % do we have HF affect perception of speed
                Sim.doHF_v0    = true;     % do we have HF affect v0
                Sim.doHeterogeneity = true; % do we vary with critical task saturation?
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);      
%% MODERATE VISIBILITY AT 93m
		   case 'scenBase_V=93m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 93;      % m visibility distance associated with the time headways (assumed)
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
                
           case 'scenBase_RT_V=93m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 93;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_TD    = true;          % do we have HF affect Task Difficulty
                Sim.doHF_tau   = true;     % do we have tau 
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
                
           case 'scenBase_RT_PES_V=93m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 93;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_s= true;     % do we have HF affect perception of distance gaps
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
                
           case 'scenBase_RT_PEV_V=93m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 93;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_v= true;     % do we have HF affect perception of speed
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);  
                
           case 'scenBase_RT_PESV_V=93m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 93;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_s= true;     % do we have HF affect perception of distance gaps
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD); 
                
           case 'scenBase_RT_PESV_BAV_V=93m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 93;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_s= true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v= true;     % do we have HF affect perception of speed
                Sim.doHF_v0    = true;     % do we have HF affect v0
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);  
                
           case 'scenBase_RT_PESV_BAV_H_V=93m'
                Sim.mu         = 0.6;      % - coefficient of friction
                Sim.ri         = 0.0;      % mm/h rain intensity per hour
                Sim.visibility = 93;      % m visibility distance associated with the time headways (assumed)
                Sim.doHF_tau   = true;     % do we have tau 
                Sim.doHF_perc_s= true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v= true;     % do we have HF affect perception of speed
                Sim.doHF_v0    = true;     % do we have HF affect v0
                Sim.doHeterogeneity = true; % do we vary with critical task saturation?
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD); 
                
%% LOW VISIBILITY AT 41m                
           case 'scenBase_V=41m_rt'
                Sim.mu         = 0.6;           % - coefficient of friction
                Sim.ri         = 0.0;           % mm/h rain intensity per hour
                Sim.visibility = 41;            % m visibility distance associated with the time headways (assumed)
                Sim.doHF_TD    = true;          % do we have HF affect Task Difficulty
                Sim.doHF_perc_s     = true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v     = true;     % do we have HF affect perception of speed differences conserving bottleneck?
                Sim.doHF_tau   = true;     % do we have tau 
                
				inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);

        end
   
       % close current figs
        close all;
        
        % run simulations--------------------------------------------------
        Sim = simulation_fcn(Sim);
        %------------------------------------------------------------------
        % recieve information from the detectors---------------------------
        Sim = vLoopDet(Sim);
        %------------------------------------------------------------------
        % Calculate KPI's--------------------------------------------------
        % % My code goes here. Compute the followings:
        % % st     : stands for space - time
        % % TDC    : Total Distance Covered
        % % TTS    : Total Time Spent
        % % Edie.q : q = d(wmega) / |wmega|
        % % Edie.k : k = t(wmega) / |wmega|
        Sim = Edie(Sim);
        %% Display here the KPI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        fprintf('\n---------KPI---------\n');
%         fprintf('TTS = %.3f [min]\n',Sim.Edie.TTS * 60);
%         fprintf('TTC_CRIT = %.1f  [s]\n',Sim.TTC_crit);
%         fprintf('TDC = %.1f  [km]\n',Sim.Edie.TDC);
%         fprintf('MEAN_SPEED = %.1f  [km/h]\n', Sim.Edie.u);
%         fprintf('CAPACITY = %.1f [veh/h]\n', Sim.Edie.q);
%         fprintf('DENSITY = %.1f [veh/km]\n', Sim.Edie.k)
%         fprintf('-------------------------\n');
        
        disp(table([Sim.Edie.TTS * 60; Sim.TTC_crit; Sim.Edie.u; Sim.Edie.q...
            ; Sim.Edie.k ],'VariableNames',{'Value'}, 'RowName',{'TTS', 'TTC_CRIT',...
            'MEAN_SPEED','CAPACITY', 'DENSITY' }));
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % figures----------------------------------------------------------
        if dofig
            % visualisations
            figs = visualisation_fcn(Sim);
        end
        %------------------------------------------------------------------
        % save data?-------------------------------------------------------
        if dosavedata
            disp('saving everything ...');
            
            if ~isdir(fullfile(pwd,'FogResults'))
                mkdir(pwd,'FogResults')
            end;
            fname = sprintf('FogResults/%s_%s.mat',Sim.scenario, tau_str);
            save(fname,'Sim');
        end;
        %------------------------------------------------------------------
        % save figures?----------------------------------------------------
        if dosavefig
            % we need the figs ...
            if ~dofig
                figs = visualisation_fcn(Sim);
            end;
            % export graphs to png
            if ~isdir(fullfile(pwd,'FogImages'))
                mkdir(pwd,'FogImages');
            end;
            exportgraphics(figs.Traj  ,sprintf('FogImages/%s_%s_traj.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.HF    ,sprintf('FogImages/%s_%s_hf.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.FDTD  ,sprintf('FogImages/%s_%s_fdtd.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.FD    ,sprintf('FogImages/%s_%s_fd.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.FDsel ,sprintf('FogImages/%s_%s_fdsel.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.Demand,sprintf('FogImages/%s_%s_demand.png',Sim.scenario,tau_str),'Resolution', 300);
			exportgraphics(figs.HEADACC,sprintf('FogImages/%s_%s_accheadspeed.png',Sim.scenario,tau_str),'Resolution', 300);
% 			exportgraphics(figs.PPD,sprintf('FogImages/%s_%s_virtualDetectors.png',Sim.scenario,tau_str),'Resolution', 300);
        end
        %------------------------------------------------------------------
        %% Here we clean the memory from the variable Sim, so as to 
        ... safeguard that every simulation contains unique results!
        clear Sim.Qvlp;
        clear Sim.Vvlp;
        clear Sim.Rhovlp;
        
        disp('DONE');
    end
end

Sim.numscen = numscen;

return;
%% Below follow cells with code to generate the two-column result graphs 
%  and the results table used in the manuscript

%% Compute TTS and num inc table
tbl_TTS = zeros(5, numscen);
tbl_INC = zeros(5, numscen);
tbl_TDC = zeros(5, numscen); % density
taus = [1,2,3,4];
for itau = 1:numel(taus)
    aTaustr = sprintf('tau=%.2d',taus(itau));
    for iscenario = 1:numscen
        aScenario = scenarios{iscenario};
        fname = sprintf('RainResults/%s_%s.mat',aScenario, aTaustr);
        load(fname);
        tbl_TTS(itau, iscenario) = Sim.TTS;
        tbl_INC(itau, iscenario) = Sim.numCollisions;
        tbl_TDC(itau, iscenario) = Sim.TDC;
    end
end;

fname = 'tbls2.xls'
xlswrite(fname,scenarios,'A1');
xlswrite(fname,[tbl_TTS; tbl_INC; tbl_TDC],'A2');

    
