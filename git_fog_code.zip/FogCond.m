%% General sim preparations for Rain Conditions
% clear up
clear all variables; clc;

dofig  = false;
dosavedata = true;
dosavefig  = true;

% timeline
Sim.dt       = 0.1;             % sec
Sim.Tsim     = 15*60;           % sec
Sim.timeline = 0:Sim.dt:Sim.Tsim-Sim.dt;    % sec
Sim.numsteps = numel(Sim.timeline);
% update progress every ... steps
Sim.dtprogress = 450;
% road stretch
Sim.xstart =  0;
Sim.xmax   = 6e3;  % exit at 3 km
% max nr of vehicles generated:
Sim.numvehicles = 350;
% Safe zone: we cannot apply reaction time logic close to origin.
Sim.safezone = 5*40; % 5 (sec) * 40 (m/s) (ultra long reaction time * very high speed)

%% Scenario preparations

% base OD profile (sine curve)
q = zeros(size(Sim.timeline));
sinebase  = 1+sin(1.5*pi/Sim.Tsim * Sim.timeline);
% qbase = 900 * sinebase;
qbase = [900  * ones(1,0.1*Sim.numsteps), ...
    2200 * ones(1,0.3*Sim.numsteps), ...
    900  * ones(1,0.6*Sim.numsteps)];

%qbase = 1400  * ones(1,Sim.numsteps);
%q = poissrnd(qbase);
Sim.q = qbase;
%% here's the list of scenario's
scenarios = { ...
%    'scenarioClear',...

%     'scenarioModerate_TD_RT' ,...
%     'scenarioModerate_TD_RT_PES',...
%     'scenarioModerate_TD_RT_PEV',...
%     'scenarioModerate_TD_RT_PESV',...
%     'scenarioModerate_TD_RT_PESV_BAS',...
%     'scenarioModerate_TD_RT_PESV_BAT',...
%      'scenarioModerate_TD_RT_PESV_BAS_H_02',...
      'scenarioModerate_TD_RT_PESV_BAST_H_02',...

%       'scenarioLow_TD_RT' ,...
%       'scenarioLow_TD_RT_PES',...
%       'scenarioLow_TD_RT_PEV',...
%       'scenarioLow_TD_RT_PESV',...
%       'scenarioLow_TD_RT_PESV_BAS',...
%       'scenarioLow_TD_RT_PESV_BAT',...
%         'scenarioLow_TD_RT_PESV_BAS_H_02',...
%       'scenarioLow_TD_RT_PESV_BAST_H',...
};

% run over all of them
numscen = numel(scenarios);

%  I must fix this!!!(rection time)
for itau = 0
    Sim.base_tau    = itau/10;
    tau_str = sprintf('tau=%.2d',itau);
    
    fprintf('\n-------------------------\n');
    fprintf('BASE REACTION TIME = %.1f  \n',Sim.base_tau);
    fprintf('-------------------------\n');
    
    % over all the scenarios
    for iscenario = 1 : numscen
        
        % BASE Settings for the scenarios
        
       % A bottleneck at 4 and 4.5
        Sim.xDisturbance  = [4e3,4.5e3];    % disturbance location
        Sim.tDisturbance  = [1, 15] * 60;   % disturbance
        Sim.disturbanceStrength = 0.36;      % Severity (qcap = 2100 veh/h, u = 33.33 m/s)
    
         % Base scenario:
        Sim.doHF        = true;      % do we compute HF?
        Sim.doDistraction = false;   % do we simulate a distraction?
        Sim.doDisturbance = true;    % do we force an additional disturbances, lets assume a flow conserving bottleneck?
        Sim.doHeterogeneity = false; % do we vary with critical task saturation?
        %Sim.base_tau    = itau;     % do we give drivers a base reaction time?
        Sim.doHF_perc_s = false;     % do we have HF affect perception of distance gaps
        Sim.doHF_perc_v = false;     % do we have HF affect perception of speed differences
        Sim.doHF_tau    = false;     % do we have tau = tau_{senstation} + tau_{perception}
        Sim.doHF_v0     = false;     % do we have HF affect v0
        Sim.doHF_T      = false;     % do we have HF affect T
        Sim.doHF_TD     = false;     % do we have HF affect Task Difficulty
        
        % What is the perception biase of the driving population?
        Sim.doHF_prob_overestimation = 0.75;
        % Here is the same as the previous one but you work with fractions!
        % Sim.doHF_perc_s_over = 0.5;  % fraction of drivers that overestimates
        % distance gaps/speeds if set to 0, 100%
        % underestimates, if set to 1 100%
        % overestimates, and any number in between
        % yields a mix (default: 50-50)
        % selected vehicles for HF plots
        Sim.iHF = [60,200];
        
        % select scenario
        Sim.scenario = scenarios{iscenario};
        switch Sim.scenario
            
            case 'scenarioClear'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 493;
                Sim.D  = 1.2/1.2;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
                
            case 'scenarioModerate_TD_RT'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 96;
                Sim.D  = 8.5/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
                
            case'scenarioModerate_TD_RT_PES'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 96;
                Sim.D  = 8.5/2.5;
                Sim.doHF_perc_s = true;     % do we have HF affect perception of distance gaps
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD); 
                
            case 'scenarioModerate_TD_RT_PEV'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 96;
                Sim.D  = 8.5/2.5;
                Sim.doHF_perc_v = true;     
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);   
                
            case 'scenarioModerate_TD_RT_PESV'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 96;
                Sim.D  = 8.5/2.5;
                Sim.doHF_perc_v = true; 
                Sim.doHF_perc_s = true; 
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD); 
            case'scenarioModerate_TD_RT_PESV_BAS'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 96;
                Sim.D  = 8.5/2.5;
                Sim.doHF_perc_v = true; 
                Sim.doHF_perc_s = true; 
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_v0     = true;     % do we have HF affect v0
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD); 

            case 'scenarioModerate_TD_RT_PESV_BAT'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 96;
                Sim.D  = 8.5/2.5;
                Sim.doHF_perc_v = true; 
                Sim.doHF_perc_s = true; 
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_v0     = false;     % do we have HF affect v0
                Sim.doHF_T      = true;     % do we have HF affect T
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD); 
%% here we perform a fast sensitivity analysis for the v0fac ~{0.1,0.4}
            case 'scenarioModerate_TD_RT_PESV_BAS_H_02'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 96;
                Sim.D  = 8.5/2.5;
                Sim.doHF_perc_v = true; 
                Sim.doHF_perc_s = true; 
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_v0     = true;     % do we have HF affect v0
                Sim.doHeterogeneity = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD); 

            case 'scenarioLow_TD_RT'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 41;
                Sim.D  = 8.9/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
           
            case 'scenarioLow_TD_RT_PES'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 41;
                Sim.D  = 8.9/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_perc_s = true;     % do we have HF affect perception of distance gaps
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
           
           case 'scenarioLow_TD_RT_PEV'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 41;
                Sim.D  = 8.9/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_perc_v = true;     % do we have HF affect perception of distance gaps
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
           
          case 'scenarioLow_TD_RT_PESV'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 41;
                Sim.D  = 8.9/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_perc_s = true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v = true;     
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
                
            case 'scenarioLow_TD_RT_PESV_BAS'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 41;
                Sim.D  = 8.9/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_perc_s = true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v = true;     
                Sim.doHF_v0     = true;     % do we have HF affect v0
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
            
            case 'scenarioLow_TD_RT_PESV_BAT'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis  = 41;
                Sim.D  = 8.9/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_perc_s = true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v = true;     
                Sim.doHF_T     = true;     % do we have HF affect T
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);

            case 'scenarioLow_TD_RT_PESV_BAS_H_02'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis = 41;
                Sim.D  = 8.9/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_perc_s = true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v = true;     
                Sim.doHF_v0     = true;     % do we have HF affect v0
                Sim.doHeterogeneity = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);

            case 'scenarioLow_TD_RT_PESV_BAS_H_randn'
                Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis = 41;
                Sim.D  = 8.9/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_perc_s = true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v = true;     
                Sim.doHF_v0     = true;     % do we have HF affect v0
                Sim.doHeterogeneity = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);

            case 'scenarioModerate_TD_RT_PESV_BAST_H_02'
              Sim.mu = 0.6;
                Sim.ri = 0.0;
                Sim.vis = 41;
                Sim.D  = 8.9/2.5;
                Sim.doHF_tau   = true;
                Sim.doHF_TD    = true;
                Sim.doHF_perc_s = true;     % do we have HF affect perception of distance gaps
                Sim.doHF_perc_v = true;     
                Sim.doHF_v0     = true;     % do we have HF affect v0
                Sim.doHF_T     = true;     % do we have HF affect T
                Sim.doHeterogeneity = true;
                inParPlot(Sim.doHF, Sim.doDisturbance, Sim.doHeterogeneity, Sim.doHF_tau, Sim.doHF_perc_s, Sim.doHF_perc_v,Sim.doHF_v0, Sim.doHF_T, Sim.doHF_TD);
  
        end
        
             % close current figs
        close all;
        
        % run simulations--------------------------------------------------
        Sim = simulation_fcn(Sim);
        %------------------------------------------------------------------
        % recieve information from the detectors---------------------------
        Sim = vLoopDet(Sim);
        %------------------------------------------------------------------
        % Calculate KPI's--------------------------------------------------
        % % My code goes here. Compute the followings:
        % % st     : stands for space - time
        % % TDC    : Total Distance Covered
        % % TTS    : Total Time Spent
        % % Edie.q : q = d(wmega) / |wmega|
        % % Edie.k : k = t(wmega) / |wmega|
        Sim = Edie(Sim);
        %% Display here the KPI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        fprintf('\n---------KPI---------\n');
%         fprintf('TTS = %.3f [min]\n',Sim.Edie.TTS * 60);
%         fprintf('TTC_CRIT = %.1f  [s]\n',Sim.TTC_crit);
%         fprintf('TDC = %.1f  [km]\n',Sim.Edie.TDC);
%         fprintf('MEAN_SPEED = %.1f  [km/h]\n', Sim.Edie.u);
%         fprintf('CAPACITY = %.1f [veh/h]\n', Sim.Edie.q);
%         fprintf('DENSITY = %.1f [veh/km]\n', Sim.Edie.k)
%         fprintf('-------------------------\n');
        
        disp(table([Sim.Edie.TTS * 60; Sim.TTC_crit; Sim.Edie.u; Sim.Edie.q...
            ; Sim.Edie.k ],'VariableNames',{'Value'}, 'RowName',{'TTS', 'TTC_CRIT',...
            'MEAN_SPEED','CAPACITY', 'DENSITY' }));
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % figures----------------------------------------------------------
        if dofig
            % visualisations
            figs = visualisation_fcn(Sim);
        end
        %------------------------------------------------------------------
        % save data?-------------------------------------------------------
        if dosavedata
            disp('saving everything ...');
            
            if ~isfolder(fullfile(pwd,'FogResults'))
                mkdir(pwd,'FogResults')
            end
            fname = sprintf('FogResults/%s_%s.mat',Sim.scenario, tau_str);
            save(fname,'Sim');
        end
        %------------------------------------------------------------------
        % save figures?----------------------------------------------------
        if dosavefig
            % we need the figs ...
            if ~dofig
                figs = visualisation_fcn(Sim);
            end
            % export graphs to png
            if ~isfolder(fullfile(pwd,'FogImages'))
                mkdir(pwd,'FogImages');
            end
            exportgraphics(figs.Traj  ,sprintf('FogImages/%s_%s_traj.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.HF    ,sprintf('FogImages/%s_%s_hf.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.FDTD  ,sprintf('FogImages/%s_%s_fdtd.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.FD    ,sprintf('FogImages/%s_%s_fd.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.FDsel ,sprintf('FogImages/%s_%s_fdsel.png',Sim.scenario,tau_str),'Resolution', 300);
            exportgraphics(figs.Demand,sprintf('FogImages/%s_%s_demand.png',Sim.scenario,tau_str),'Resolution', 300);
			exportgraphics(figs.HEADACC,sprintf('FogImages/%s_%s_accheadspeed.png',Sim.scenario,tau_str),'Resolution', 300);
% 			exportgraphics(figs.PPD,sprintf('FogImages/%s_%s_virtualDetectors.png',Sim.scenario,tau_str),'Resolution', 300);
        end
        %------------------------------------------------------------------
        %% Here we clean the memory from the variable Sim, so as to 
        ... safeguard that every simulation contains unique parameters!
        clear Sim.Qvlp;
        clear Sim.Vvlp;
        clear Sim.Rhovlp;
        
        disp('DONE');
         
    end
end

Sim.numscen = numscen;

return;
